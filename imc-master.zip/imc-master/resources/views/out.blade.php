<h1>imc:{{$imc}}</h1>
<br>
<h1>tipo:{{$tipo}}<h1>
